﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Rectangle : Shape
    {
        public Rectangle(double height, double width)
        {
            Height = height;
            Width = width;
        }

        private double height;

        public double Height
        {
            get
            {
                return height;
            }
            private set
            {
                height = value;
            }
        }

        public double Width
        {
            get
            {
                return height;
            }
            private set
            {
                height = value;
            }
        }

        public override double CalculatePerimeter()
        {
            return 2 * Height + 2 * Width;
        }

        public override double CalculateArea()
        {
            return Height * Width;
        }

        public override string Draw()
        {
            //StringBuilder sb = new StringBuilder();

            //DrawLine(Width, '*', '*', sb);
            //for (int i = 1; i < this.Height - 1; ++i)
            //{
            //    DrawLine(Width, '*', ' ', sb);
            //}
            //DrawLine(this.Width, '*', '*', sb);

            return "Rectangle";
        }

        //private void DrawLine(double width, char end, char mid, StringBuilder sb)
        //{
        //    sb.Append(end);
        //    for (int i = 1; i < width - 1; ++i)
        //    {
        //        sb.Append(mid);
        //    }
        //    sb.AppendLine(end.ToString());
        //}
    }
}
